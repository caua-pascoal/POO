package br.com.cefet.banco.modelo;

public class ContaPoupanca extends Conta {
	public ContaPoupanca(int numero) {
		super(numero);
	}
}
