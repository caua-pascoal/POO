package br.com.cefet.banco.modelo;

public abstract class Secretaria extends Funcionario{

}
