package br.com.cefet.banco.modelo;

public class SecretariaDaGerencia extends Secretaria{

	@Override
	public double getBonificacaoNatalina() {
		// TODO Auto-generated method stub
		return 0;
	}

}
